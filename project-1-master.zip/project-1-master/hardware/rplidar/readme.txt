requires rplidar module from https://github.com/SkoltechRobotics/rplidar
pip install rplidar

